const { Given, When, Then } = require('@badeball/cypress-cucumber-preprocessor');

Given('I open login page upscale#10',()=>{
    cy.clearCookies();
    cy.visit('https://upscale.edudev.xyz/')
})

When('I click login menu upscale#10',()=>{
    cy.get('.btn-login').click()
})

When('I fill the login form upscale#10',()=>{
    cy.get('#email').type('ammarhtr@gmail.com')
    cy.get('.col-lg-8 > #Password').type('Fu86MEhYLAWhnBidfKm4')
    
})

When('I click login button#10',()=>{
    cy.get('#login').click()  
})

When('I click logout button#10',()=>{
    cy.xpath("//a[contains(.,'Hello Naufal Ammar')]").eq(0).trigger('mouseover')  
    cy.pause()
})